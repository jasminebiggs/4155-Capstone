from fastapi import FastAPI
from pydantic import BaseModel
from database import database, sessions
from routes.ratings import router as ratings_router, RatingInput, rate_partner
from routes.matches import router as matches_router
from routes.match_engine import router as match_engine_router

app = FastAPI()

app.include_router(ratings_router)
app.include_router(matches_router)
app.include_router(match_engine_router)

@app.on_event("startup")
async def startup():
    await database.connect()

@app.on_event("shutdown")
async def shutdown():
    await database.disconnect()

class SessionCreate(BaseModel):
    student_id: int
    partner_id: int
    start_time: str
    end_time: str

@app.post("/sessions/schedule", status_code=201)
async def schedule_session(session: SessionCreate):
    query = '''
        INSERT INTO sessions (student_id, partner_id, start_time, end_time)
        VALUES (:student_id, :partner_id, :start_time, :end_time)
    '''
    values = {
        "student_id": session.student_id,
        "partner_id": session.partner_id,
        "start_time": session.start_time,
        "end_time": session.end_time
    }
    await database.execute(query=query, values=values)
    return {"message": "Session scheduled successfully!"}
@app.get("/ping")
def ping():
    return {"message": "Server is working!"}
