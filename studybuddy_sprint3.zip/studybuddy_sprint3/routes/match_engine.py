# Sprint 3 Ticket #37: This route connects the matching algorithm to the backend.
# It takes in a student's profile (subjects, availability, personality) and compares it
# to other existing users to find the top 3 study partners with the best match score.
# This helps students get real-time match results when they sign up or request partners.

from fastapi import APIRouter
from pydantic import BaseModel
from typing import List

router = APIRouter()

class UserProfile(BaseModel):
    user_id: int
    subjects: List[str]
    availability: List[str]
    personality: str

def run_matching_algorithm(new_user: UserProfile, existing_users: List[UserProfile]):
    matches = []

    for user in existing_users:
        if user.user_id == new_user.user_id:
            continue

        shared_subjects = set(new_user.subjects) & set(user.subjects)
        shared_times = set(new_user.availability) & set(user.availability)
        same_personality = new_user.personality == user.personality

        score = len(shared_subjects) + len(shared_times)
        if same_personality:
            score += 1

        matches.append((user.user_id, score))

    matches.sort(key=lambda x: x[1], reverse=True)
    return [match[0] for match in matches[:3]]

@router.post("/match")
async def match_user(new_user: UserProfile):
    existing_users = [
        UserProfile(user_id=2, subjects=["math", "science"], availability=["morning"], personality="A"),
        UserProfile(user_id=3, subjects=["history", "math"], availability=["evening"], personality="B"),
        UserProfile(user_id=4, subjects=["math", "science"], availability=["morning"], personality="A"),
    ]

    best_matches = run_matching_algorithm(new_user, existing_users)

    return {
        "user_id": new_user.user_id,
        "top_matches": best_matches
    }
