# Sprint 3 Ticket #35: This route allows a student to view their matched study partners.
# It checks the "sessions" table in the database for any rows where the student's ID appears.
# Then, it collects all unique partner IDs that the student has had sessions with.
# If no matches are found, it returns a 404 error. Otherwise, it returns a JSON response
# showing the student’s ID and a list of their matched partner IDs.

from fastapi import APIRouter, HTTPException
from database import database, sessions

router = APIRouter()

@router.get("/matches/{user_id}")
async def get_matched_partners(user_id: int):
    query = sessions.select().where(sessions.c.student_id == user_id)
    results = await database.fetch_all(query)

    if not results:
        raise HTTPException(status_code=404, detail="No matches found for this user")

    matched_partner_ids = list(set([row["partner_id"] for row in results]))

    return {
        "user_id": user_id,
        "matched_partners": matched_partner_ids
    }
